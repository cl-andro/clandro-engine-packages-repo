##
## This script is sourced by /data/data/com.clandro.b2b/files/usr/bin/login before executing shell.
##
