#!/data/data/com.clandro.b2b/files/usr/bin/sh

echo "$@"
