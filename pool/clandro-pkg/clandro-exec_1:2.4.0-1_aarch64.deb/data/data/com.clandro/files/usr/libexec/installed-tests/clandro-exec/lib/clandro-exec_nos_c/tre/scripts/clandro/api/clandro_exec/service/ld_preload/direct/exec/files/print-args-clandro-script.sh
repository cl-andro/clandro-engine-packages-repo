#!/data/data/com.clandro/files/usr/bin/sh

echo "$@"
