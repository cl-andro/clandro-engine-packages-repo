set(RESOLV_WRAPPER_LIBRARY /data/data/com.clandro/files/usr/lib/libresolv_wrapper.so)
