##
## This script is sourced by /data/data/com.clandro/files/usr/bin/login before executing shell.
##
