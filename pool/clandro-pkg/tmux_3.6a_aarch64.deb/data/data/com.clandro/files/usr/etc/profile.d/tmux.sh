export TMUX_TMPDIR=/data/data/com.clandro/files/usr/var/run
