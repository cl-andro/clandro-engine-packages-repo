#!/data/data/com.clandro/files/usr/bin/sh

. "${CLANDRO__PREFIX:-"${PREFIX}"}"/libexec/source-ssh-agent.sh
"${wrapped_cmd}" "$@"
